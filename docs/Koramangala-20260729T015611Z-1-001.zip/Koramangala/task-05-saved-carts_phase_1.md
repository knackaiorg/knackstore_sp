# Task 05 — Saved Carts

## Discovery Session Transcript

**Project:** KnackStore — Electronics E-Commerce Platform **Session:** Feature Discovery Workshop **Date:** July 22, 2026 **Location:** TechStore HQ, Conference Room B2

**Attendees:**

- **Sarah Mitchell** — Business Analyst, Knack Systems  
- **Rahul Mehta** — Product Manager, KnackStore  
- **Sneha Kapoor** — Merchandising Lead, KnackStore  
- **Arjun Sharma** — Solution Architect, Knack Systems

---

**Sarah:** Last one for this round — Saved Carts. What's driving this?

**Sneha:** Customers building out multiple shopping lists — say, one for a home office setup and one for gifts — and not wanting to lose either one just because they're only ready to buy one right now.

**Sarah:** So this lives alongside the regular cart, not instead of it?

**Rahul:** Right. A "Save Cart" action on the cart page that takes a snapshot. It shouldn't clear or touch what's currently in their active cart — saving is additive, not destructive.

**Sarah:** Can someone save more than one cart?

**Rahul:** Yes, as many as they want. Each save is its own separate entry, not an overwrite of the last one.

**Sarah:** Where do these saved carts live?

**Sneha:** A new page under My Account — "Saved Carts."

**Sarah:** What does that list need to show for each one?

**Rahul:** Cart number, how many SKUs are in it, and the total price. Enough for someone to recognize which cart is which without opening every single one.

**Sarah:** And clicking into one?

**Rahul:** Opens a detail page — every product in that cart, with quantity and price.

**Sarah:** What actions live on that detail page?

**Rahul:** Three things. Delete the whole saved cart. Add everything in it straight to their actual cart. And remove just one product from it, if they've changed their mind about a single item but want to keep the rest of the list.

**Sarah:** If they hit "add to cart" on a saved cart, and it merges with what's already in their active cart — what if a saved item has gone out of stock since they saved it?

**Arjun:** Same pattern as Quick Order, honestly — re-check stock at the moment of adding, exclude anything unavailable, and tell the customer clearly which item didn't make it rather than failing the whole action.

**Sarah:** Makes sense to keep that consistent across features. What price shows on the saved cart — what it cost when they saved it, or today's price?

**Arjun:** I'd snapshot the price at save time. That's genuinely what "saved cart" implies — it's a point-in-time list, not a live one.

**Sneha:** Agreed, that also avoids weird totals shifting on the list page every time a price changes elsewhere on the site.

**Sarah:** Good, that answers it. Let me summarize.

Customers can save their entire current cart from the cart page without affecting their active cart, and can save multiple carts over time. A new Saved Carts page under My Account lists each one with its cart number, SKU count, and total price. Opening a saved cart shows every product in it, with options to delete the entire saved cart, remove an individual product from it, or add everything in it to the active cart in one action — merging quantities with what's already there and excluding, with a clear message, any item that's gone out of stock since it was saved. Prices shown reflect what they were at the time the cart was saved.

**Rahul:** That covers it well. This one's more of a convenience feature, but it's the kind of thing that keeps people coming back to browse.

**Sneha:** Rounds out a solid set of five for the hackathon.

---

*End of transcript. Duration: 23 minutes.*  
