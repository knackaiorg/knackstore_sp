# Task 05 — Saved Carts Enhancement

## Discovery Session Transcript

**Project:** KnackStore — Electronics E-Commerce Platform **Session:** Post-Launch Enhancement Session **Date:** July 24, 2026 **Location:** TechStore HQ, Conference Room B2

**Attendees:**

- **Sarah Mitchell** — Business Analyst, Knack Systems  
- **Rahul Mehta** — Product Manager, KnackStore  
- **Sneha Kapoor** — Merchandising Lead, KnackStore  
- **Arjun Sharma** — Solution Architect, Knack Systems

---

**Sarah:** So Saved Carts has been live a couple days. What are we hearing?

**Sneha:** A few things, actually. First one — people want to name their carts. Right now it's just an auto-generated number, and if you've saved a couple, you genuinely can't tell them apart without opening each one.

**Rahul:** Right, so we want a name field when they save. "Home Office Setup," "Gift List," whatever makes sense to them.

**Sarah:** And if they don't bother typing one?

**Rahul:** Falls back to a generated name, same as today. Shouldn't be a required field.

**Sarah:** What's the second thing?

**Sneha:** People saving the same kind of cart over and over. They add a couple things, save again, and now they've got three or four almost-identical saved carts cluttering the list.

**Rahul:** So on that same save step, give them the choice — save as something new, or pick one of their existing saved carts and update it instead.

**Sarah:** Got it. Anything about how it looks?

**Rahul:** Yeah, that whole save step should feel nicer. Right now it's just sitting inline on the cart page like an afterthought — we want it to open as a proper popup. Name field, the option to pick an existing cart to update, save button, done.

**Sneha:** And while we're at it, there's a "View Saved Carts" link sitting on the cart page that we don't need anymore — it's already reachable from My Account, no reason to have it twice.

**Sarah:** Makes sense, I'll note all of that. Let's move on unless there's more.

**Sneha:** Actually, one more — this one came in after the name and update options were already live. Someone updated one of their saved carts, added a couple of new things to it, hit save — and when they opened it back up, the new items weren't there. Just the old stuff, like nothing had changed.

**Sarah:** So the update wasn't actually replacing what was saved.

**Sneha:** Right, it looked like it saved successfully, but the contents underneath didn't move.

**Arjun:** That's a real one — updating a saved cart needs to properly swap in whatever's in the active cart at that moment. Old items that aren't there anymore should be gone, not sitting around next to the new ones.

**Rahul:** Agreed, that needs to be fixed before we call this done. An "update" that quietly keeps stale data isn't an update.

**Sarah:** Anything else come up?

**Sneha:** Yeah — for a little while, saving a cart was just failing outright. People were getting a message saying it couldn't save and to try again, no obvious reason why.

**Arjun:** That got sorted — it was tied to the same overwrite logic, once that was handled properly the save errors went away with it.

**Sarah:** Good. And I heard there was some back-and-forth getting things running again afterward?

**Rahul:** A bit, yeah — a couple of restarts, some port conflicts along the way, nothing to do with the feature itself. Everything came back up clean, both sides were reachable again once that settled.

**Sarah:** Okay, let me sum up where this landed.

Saved Carts now lets a customer name a cart themselves when they save it, falling back to an auto-generated name if they skip it. From that same save step, they can choose to update one of their existing saved carts instead of always creating a new one, and doing so fully replaces that cart's contents with whatever's currently in their active cart — no leftover items from before. The save action itself now opens as a popup rather than sitting inline on the cart page, and the redundant "View Saved Carts" link has been removed from there since the page is already reachable from My Account. The earlier issue where an update didn't actually refresh the saved contents, and the save failures that came with it, have both been resolved.

**Rahul:** Good, that's a clean close on this one.

**Sneha:** Should feel a lot more useful now for anyone managing more than one saved cart.

---

*End of transcript. Duration: 21 minutes.*
